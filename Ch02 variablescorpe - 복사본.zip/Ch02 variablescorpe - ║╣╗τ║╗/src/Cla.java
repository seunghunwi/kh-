
public class Cla {

	int add(int a, int b) {		  
		return a + b;
	}
	int add1(int a, int b) {		 
		return a - b;
	}
	int add2(int a, int b) {
		return a * b;
	}
	int add3(int a ,int b) {
		return  a / b;
	} 
	double add4(double a) {		 
		return  3.14*a*3;		
	}
	double add5(double a) {		 
		return  2*3.14*a;		
	} 

}
